# Example documents (synthetic)

Every file here is synthetic: fake people, companies, GSTINs and amounts. Drag a pair into the PaperTrail demo's
upload slots (or use "Use pair" in the demo). Because these exact files are bundled with the demo, their
extraction is precomputed with the live engine: they work instantly and never use model quota.


## payables

1. **Clean invoice (paraphrased lines)**: seeded issue: nothing (should approve).
   - `payables-01-clean-invoice.jpg` (invoice)
   - `payables-01-clean-purchase_order.jpg` (purchase order)
2. **Rate above PO and quantity over PO**: seeded issue: rate above po, qty over po.
   - `payables-02-overbilled-invoice.jpg` (invoice)
   - `payables-02-overbilled-purchase_order.jpg` (purchase order)
3. **Wrong tax split and invalid GSTIN**: seeded issue: wrong tax split, invalid gstin.
   - `payables-03-tax-invoice.jpg` (invoice)
   - `payables-03-tax-purchase_order.jpg` (purchase order)
4. **Invoice bills an item that was never ordered**: seeded issue: line not on po.
   - `payables-04-extra_line-invoice.jpg` (invoice)
   - `payables-04-extra_line-purchase_order.jpg` (purchase order)
5. **Different vendor GSTIN and a wrong grand total**: seeded issue: gstin mismatch, total mismatch.
   - `payables-05-vendor-invoice.jpg` (invoice)
   - `payables-05-vendor-purchase_order.jpg` (purchase order)
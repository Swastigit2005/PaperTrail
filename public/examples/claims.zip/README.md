# Example documents (synthetic)

Every file here is synthetic: fake people, companies, GSTINs and amounts. Drag a pair into the PaperTrail demo's
upload slots (or use "Use pair" in the demo). Because these exact files are bundled with the demo, their
extraction is precomputed with the live engine: they work instantly and never use model quota.


## claims

1. **Clean claim (brand vs generic names)**: seeded issue: nothing (should approve).
   - `claims-01-clean-prescription.jpg` (prescription)
   - `claims-01-clean-bill.jpg` (bill)
2. **Bill includes a medicine that was not prescribed**: seeded issue: unprescribed medicine.
   - `claims-02-unprescribed-prescription.jpg` (prescription)
   - `claims-02-unprescribed-bill.jpg` (bill)
3. **Billed quantity far exceeds the prescribed course**: seeded issue: implausible quantity, bill before prescription.
   - `claims-03-quantity-prescription.jpg` (prescription)
   - `claims-03-quantity-bill.jpg` (bill)
4. **Bill is for a different patient**: seeded issue: patient name mismatch.
   - `claims-04-patient-prescription.jpg` (prescription)
   - `claims-04-patient-bill.jpg` (bill)
5. **Bill totals do not add up**: seeded issue: arithmetic error.
   - `claims-05-arithmetic-prescription.jpg` (prescription)
   - `claims-05-arithmetic-bill.jpg` (bill)
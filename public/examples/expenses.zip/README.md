# Example documents (synthetic)

Every file here is synthetic: fake people, companies, GSTINs and amounts. Drag a pair into the PaperTrail demo's
upload slots (or use "Use pair" in the demo). Because these exact files are bundled with the demo, their
extraction is precomputed with the live engine: they work instantly and never use model quota.


## expenses

1. **Clean meal claim**: seeded issue: nothing (should approve).
   - `expenses-01-clean-receipt.jpg` (receipt)
   - `expenses-01-clean-expense_claim.jpg` (expense claim)
2. **Claimed amount exceeds the receipt**: seeded issue: claim amount mismatch.
   - `expenses-02-inflated-receipt.jpg` (receipt)
   - `expenses-02-inflated-expense_claim.jpg` (expense claim)
3. **Same receipt claimed again (duplicate)**: seeded issue: duplicate receipt.
   - `expenses-03-duplicate-receipt.jpg` (receipt)
   - `expenses-03-duplicate-expense_claim.jpg` (expense claim)
4. **Receipt older than the 30-day policy window**: seeded issue: outside policy window.
   - `expenses-04-late-receipt.jpg` (receipt)
   - `expenses-04-late-expense_claim.jpg` (expense claim)
5. **Clean team-lunch claim (phone scan)**: seeded issue: nothing (should approve).
   - `expenses-05-clean_2-receipt.jpg` (receipt)
   - `expenses-05-clean_2-expense_claim.jpg` (expense claim)